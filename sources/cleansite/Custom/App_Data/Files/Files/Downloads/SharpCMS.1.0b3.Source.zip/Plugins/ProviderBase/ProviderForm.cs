//Sharpcms.net is licensed under the open source license GPL - GNU General Public License.
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Net.Mail;
using System.Net;
using InventIt.SiteSystem;
using InventIt.SiteSystem.Plugin;
using InventIt.SiteSystem.Library;

namespace InventIt.SiteSystem.Providers
{
    public class ProviderForm : BasePlugin2, IPlugin2
    {
        public new string Name
        {
            get
            {
                return "Form";
            }
        }

        public ProviderForm()
        {
        } 

        public ProviderForm(Process process)
        {
            m_Process = process;
        }

        public new void Handle(string mainEvent)
        {
            switch (mainEvent)
            {
                case "submitform":
                    HandleSubmitForm();
                    break;
            }
        }

        public void HandleSubmitForm()
        {
			StringBuilder reply = new StringBuilder();
            for (int i = 0; i < m_Process.QueryData.Count; i++)
            {
                Query current = m_Process.QueryData[i];
                if (current.Name.StartsWith("form"))
                {
					string fieldName = current.Name.Replace("form_", string.Empty).Replace("_", string.Empty);
					reply.AppendFormat("{0}: {1}\n", fieldName, current.Value);
                }
            }

			MailMessage message = new MailMessage();
			message.From = new MailAddress(m_Process.Settings["mail/servermail"]);
			message.To.Add(m_Process.Settings["mail/user"]);
			message.Subject = m_Process.Settings["mail/subject"];
			message.Body = reply.ToString();

            SmtpClient smtpClient = new SmtpClient(m_Process.Settings["mail/smtp"]);
            if (m_Process.Settings["mail/smtpuser"] != string.Empty)
            {
                smtpClient.Credentials = new NetworkCredential(
                    m_Process.Settings["mail/smtpuser"],
                    m_Process.Settings["mail/smtppass"]);
            }
            smtpClient.Send(message); 

            string confirmMessage = m_Process.Settings["mail/confirm"];
            if (confirmMessage != string.Empty)
            {
                m_Process.AddMessage(confirmMessage); 
            }
        }
    }
}