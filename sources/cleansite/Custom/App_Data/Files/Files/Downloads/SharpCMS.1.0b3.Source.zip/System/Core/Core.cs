/* $id */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using InventIt.SiteSystem.Library;

namespace InventIt.SiteSystem
{
	public static class Core
	{
		public static void Send(System.Web.UI.Page httpPage)
		{
            Counter counter = new Counter();
            counter.Start();

            PrepareConfiguration(httpPage);

            ProcessHandler processHandler = new ProcessHandler();
            Process process = processHandler.Run(httpPage);

            if (!process.OutputHandledByModule)
            {
                Parse(httpPage, process);
                
                counter.Stop();

                httpPage.Response.Write(string.Format("<!-- {0} ms -->", counter.Milliseconds));
            }
		}

        private static void PrepareConfiguration(System.Web.UI.Page httpPage)
        {
            Cache cache = new Cache(httpPage.Application);

            List<string> configurationPaths = new List<string>();
            configurationPaths.Add(httpPage.Server.MapPath("~/Custom/Components"));
            configurationPaths.Add(httpPage.Server.MapPath("~/System/Components"));

            string[] settingsPaths = new string[3];
            configurationPaths.CopyTo(settingsPaths);
            settingsPaths[2] = httpPage.Server.MapPath("~/Custom/App_Data/CustomSettings.xml");
            Configuration.CombineSettings(settingsPaths, cache);

            string[] processPaths = new string[3];
            configurationPaths.CopyTo(processPaths);
            processPaths[2] = httpPage.Server.MapPath("~/Custom/App_Data/CustomProcess.xml");
            Configuration.CombineProcessTree(processPaths, cache);
        }

        private static void Parse(System.Web.UI.Page httpPage, Process process)
        {
            if (process.QueryEvents["xml"] == "true")
            {
                httpPage.Response.AddHeader("Content-Type", "text/xml");
                httpPage.Response.Write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
                httpPage.Response.Write(process.XmlData.OuterXml);
            }
            else
            {
                if (process.mainTemplate != null)
                {
                    string output = CommonXml.TransformXsl(process.mainTemplate, process.XmlData, process.Cache);
                    // todo: dirty hack 
                    string[] badtags = { "<ul />", "<li />", "<h1 />", "<h2 />", "<h3 />", "<div />", "<p />", "<font />", "<b />", "<strong />", "<i />" };
                    foreach (string a in badtags)
                        output.Replace(a, "");

                    httpPage.Response.Write(output);
                }
            }
        }
	}
}