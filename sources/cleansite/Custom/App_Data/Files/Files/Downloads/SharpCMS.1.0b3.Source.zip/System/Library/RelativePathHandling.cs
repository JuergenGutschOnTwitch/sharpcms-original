//Sharpcms.net is licensed under the open source license GPL - GNU General Public License.
using System;
using System.Collections.Generic;
using System.Text;

namespace InventIt.SiteSystem.Library
{
	public enum RelativePathHandling
	{
		ConvertToAbsolute,
		ReturnAsIs
	}
}
