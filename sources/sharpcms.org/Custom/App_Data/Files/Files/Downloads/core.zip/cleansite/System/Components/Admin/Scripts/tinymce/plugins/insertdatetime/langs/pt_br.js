// pt_BR lang variables

tinyMCE.addToLang('',{
insertdate_desc : 'Inserir data',
inserttime_desc : 'Inserir hora',
inserttime_months_long : new Array("Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"),
inserttime_months_short : new Array("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"),
inserttime_day_long : new Array("Domindo", "Segunda-Feira", "Ter�a-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira", "S�bado", "Domingo"),
inserttime_day_short : new Array("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom")
});
