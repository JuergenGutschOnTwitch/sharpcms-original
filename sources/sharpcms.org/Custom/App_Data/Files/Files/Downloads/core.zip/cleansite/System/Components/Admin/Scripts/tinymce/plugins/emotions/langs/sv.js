// SE lang variables

tinyMCE.addToLang('emotions',{
title : 'Klistra in k&auml;nsla',
desc : 'K&auml;nslor',
cool : 'Cool',
cry : 'Gr&aring;ter',
embarassed : 'Generad',
foot_in_mouth : 'Fot i munnnen',
frown : 'Ledsen',
innocent : 'Oskyldig',
kiss : 'Kyss',
laughing : 'Skrattande',
money_mouth : 'Penga mun',
sealed : 'Hemlis',
smile : 'Glad',
surprised : 'F&ouml;rv&aring;nad',
tongue_out : 'R&auml;cka ut tungan',
undecided : 'Fundersam',
wink : 'Fl&ouml;rt',
yell : 'Skrikandes'
});
