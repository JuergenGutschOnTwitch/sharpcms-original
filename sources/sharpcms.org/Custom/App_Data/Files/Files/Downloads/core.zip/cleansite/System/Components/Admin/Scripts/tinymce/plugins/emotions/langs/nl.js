// NL lang variables

tinyMCE.addToLang('',{
insert_emotions_title : 'Emotion invoegen',
emotions_desc : 'Smilie'
});
