// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
save_desc : 'Gem'
});
