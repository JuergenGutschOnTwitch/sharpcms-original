// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
insert_flash : 'Ins�rer / Modifier une animation Flash',
insert_flash_file : 'Fichier Flash (.swf)',
insert_flash_size : 'Dimension',
insert_flash_list : 'Fichiers Flash',
flash_props : 'Propri�t�s Flash'
});
