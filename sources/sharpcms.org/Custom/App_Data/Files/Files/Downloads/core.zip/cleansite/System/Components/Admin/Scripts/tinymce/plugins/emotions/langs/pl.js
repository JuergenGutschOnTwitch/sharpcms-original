// PL lang variables

tinyMCE.addToLang('',{
insert_emotions_title : 'Wstaw emtoicone',
emotions_desc : 'Emtoicony'
});
