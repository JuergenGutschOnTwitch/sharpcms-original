// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
fullscreen_title : 'Fullskjermstilstand',
fullscreen_desc : 'Hopp fra/til fullskjermstilstand'
});
