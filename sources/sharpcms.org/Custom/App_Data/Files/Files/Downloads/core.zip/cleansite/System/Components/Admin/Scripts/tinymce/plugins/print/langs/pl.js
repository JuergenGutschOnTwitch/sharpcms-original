// PL lang variables

tinyMCE.addToLang('',{
print_desc : 'Drukuj'
});
