/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
insert_emotions_title : 'Vložit emotikonu',
emotions_desc : 'Emotikony'
});

