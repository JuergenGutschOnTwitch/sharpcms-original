// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('advimage',{
tab_general : 'Generelt',
tab_appearance : 'Udseende',
tab_advanced : 'Avanceret',
general : 'Generelt',
title : 'Overskrift',
preview : 'Se',
constrain_proportions : 'Fasthold proportioner',
langdir : 'Tekstretning',
langcode : 'Sprogkode',
long_desc : 'Langt beskrivelseslink',
style : 'Style',
classes : 'Klasser',
ltr : 'Venstre til h&#248;jre',
rtl : 'H&#248;jre til venstre',
id : 'Id',
image_map : 'Billedkort',
swap_image : 'Alternativt billede',
alt_image : 'Alternative image',
mouseover : 'ved mouse over',
mouseout : 'ved mouse out',
misc : 'Diverse',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : 'Are you sure you want to continue without including an Image Description? Without  it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.'
});
