// pt_BR lang variables

tinyMCE.addToLang('',{
insert_image_alt2 : 'T�tulo da Imagem',
insert_image_onmousemove : 'Imagem Alternativa',
insert_image_mouseover : 'para quando mouse sobre',
insert_image_mouseout : 'para quando mouse fora'
});
