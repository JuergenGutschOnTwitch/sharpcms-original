// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
insert_link_target_same : 'Ouvre dans la fen&#281;tre / Cadre(frame)',
insert_link_target_parent : 'Ouvre dans fen&#281;tre parente / Cadres(frame)',
insert_link_target_top : 'Ouvre dans le Top frame (remplace toutes les cadres(frames))',
insert_link_target_blank : 'Ouvre dans la fen&#281;tre',
insert_link_target_named : 'Ouvre dans la fen&#281;tre',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'URL de la Popup',
insert_link_popup_name : 'Nom de la fen&#281;tre',
insert_link_popup_return : 'Insert \'return false\'',
insert_link_popup_scrollbars : 'Montrer la barre de d&eacute;filement ',
insert_link_popup_statusbar : 'Montrer la barre d\'&eacute;tat',
insert_link_popup_toolbar : 'Montrer la barre d\'outils',
insert_link_popup_menubar : 'Montrer la barre du menu',
insert_link_popup_location : 'Montre la barre d\'adresse',
insert_link_popup_resizable : 'Fabriquer une fen&#281;tre redimensionnable',
insert_link_popup_size : 'Taille',
insert_link_popup_position : 'Position (X/Y)',
insert_link_popup_missingtarget : 'Veuillez ins&eacute;rer un nom pour la cible ou choisissez une autre option.'
});
