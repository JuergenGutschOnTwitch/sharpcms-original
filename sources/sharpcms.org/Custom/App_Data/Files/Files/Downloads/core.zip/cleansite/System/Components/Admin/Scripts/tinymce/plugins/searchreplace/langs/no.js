// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
searchreplace_search_desc : 'S&oslash;k',
searchreplace_searchnext_desc : 'S&oslash;k igjen',
searchreplace_replace_desc : 'S&oslash;k/Erstatt',
searchreplace_notfound : 'S&oslash;kingen avsluttet. Fant ikke s&oslash;kestrengen.',
searchreplace_search_title : 'S&oslash;k',
searchreplace_replace_title : 'S&oslash;k/Erstatt',
searchreplace_allreplaced : 'Alle treff p&aring; s&oslash;kestrengen erstattes',
searchreplace_findwhat : 'S&oslash;k p&aring;',
searchreplace_replacewith : 'Erstatt med',
searchreplace_direction : 'S&oslash;keretning',
searchreplace_up : 'Oppover',
searchreplace_down : 'Nedover',
searchreplace_case : 'Skill mellom store og sm&aring; tegn',
searchreplace_findnext : 'Neste s&oslash;k',
searchreplace_replace : 'Erstatt',
searchreplace_replaceall : 'Erstatt&nbsp;alle',
searchreplace_cancel : 'Avbryt'
});
