// HU lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Beilleszt�s sima sz�vegk�nt',
paste_text_title : 'Haszn�ld a CTRL+V -t a billenty�zeten a sz�veg beilleszt�s�hez az ablakba.',
paste_text_linebreaks : 'Keep linebreaks',
paste_word_desc : 'Beilleszt�s Word-b�l',
paste_word_title : 'Haszn�ld a CTRL+V -t a billenty�zeten a sz�veg beilleszt�s�hez az ablakba.',
selectall_desc : 'Mindet kijel�l'
});
