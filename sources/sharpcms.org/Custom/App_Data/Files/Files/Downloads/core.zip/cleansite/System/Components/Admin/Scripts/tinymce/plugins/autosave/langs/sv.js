// SE lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'F&ouml;r&auml;ndringarna du gjorde kommer att g&aring; f&ouml;rlorade om du v&auml;ljer att l&auml;mna denna sida.'
});

