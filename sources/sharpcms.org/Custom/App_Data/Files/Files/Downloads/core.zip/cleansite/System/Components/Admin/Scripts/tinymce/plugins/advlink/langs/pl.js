// PL lang variables

tinyMCE.addToLang('',{
insert_link_target_same : 'Otwórz w tym samym oknie',
insert_link_target_parent : 'Open in parent window / frame',
insert_link_target_top : 'Open in top frame (replaces all frames)',
insert_link_target_blank : 'Otwórz w nowym oknie',
insert_link_target_named : 'Open in the window',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'Popup URL',
insert_link_popup_name : 'Window name',
insert_link_popup_return : 'insert \'return false\'',
insert_link_popup_scrollbars : 'Show scrollbars',
insert_link_popup_statusbar : 'Show statusbar',
insert_link_popup_toolbar : 'Show toolbars',
insert_link_popup_menubar : 'Show menubar',
insert_link_popup_location : 'Show locationbar',
insert_link_popup_resizable : 'Make window resizable',
insert_link_popup_size : 'Size',
insert_link_popup_position : 'Position (X/Y)',
insert_link_popup_missingtarget : 'Please insert a name for the target or choose another option.',
insert_link_url : 'Adres URL',
insert_link_target : 'Cel'
});
