	function ThrowEvent(mainevent,mainvalue)
		{
			document.systemform.event_main.value =mainevent;
			document.systemform.event_mainvalue.value =mainvalue;
			document.systemform.submit();
		}
	function ThrowEventConfirm(mainevent,mainvalue,confirmtxt)
		{
			if (confirm(confirmtxt))
			{
				ThrowEvent(mainevent,mainvalue)
			}
		}
		
	function ThrowEventNew(mainevent,mainvalue,txt,suggest)
		{
		    if (suggest == null)
		    {
		        suggest = '';
		    }
			input = prompt(txt,suggest);
			if (input != null)
			{	if (mainvalue !='')
					{
						ThrowEvent(mainevent,mainvalue + '*' + input)
					}
				else
					{
						ThrowEvent(mainevent,input)	
					}
			}
		}


