// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
paste_text_desc : 'Inds&#230;t som ren tekst',
paste_text_title : 'Brug CTRL+V p&#229; tastaturett inds&#230;tte teksten i vinduet.',
paste_text_linebreaks : 'Behold linjebrud',
paste_word_desc : 'Inds&#230;t fra Word',
paste_word_title : 'Brug CTRL+V p&#229; tastaturett inds&#230;tte teksten i vinduet.',
selectall_desc : 'V&#230;lg alt'
});
