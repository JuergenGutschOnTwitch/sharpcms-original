// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
preview_desc : 'Forh&aring;ndsvisning'
});
