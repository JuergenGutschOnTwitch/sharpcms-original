// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
insert_advhr_desc : 'Ins&eacute;rer / &eacute;diter une R&#269;gle Horizontale',
insert_advhr_width : 'Largeur',
insert_advhr_size : 'Hauteur',
insert_advhr_noshade : 'Sans ombre'
});
